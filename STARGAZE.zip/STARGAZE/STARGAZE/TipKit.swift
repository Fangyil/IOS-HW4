import TipKit

struct PopoverTip: Tip {
    var title: Text {
        Text("Click Here!")
    }
    
    var message: Text? {
        Text("You will have more information.")
    }
    
    var image: Image? {
        Image(systemName: "cursorarrow.click.2")
    }
}

struct DragTip: Tip {
    var title: Text {
        Text("Drag it!")
    }
    
    var message: Text? {
        Text("You can move it to wherever you want.")
    }
    
    var image: Image? {
        Image(systemName: "hand.draw.fill")
    }
}
