//
//  STARGAZEApp.swift
//  STARGAZE
//
//  Created by 林芳儀 on 2023/12/12.
//

import SwiftUI
import MijickPopupView
import TipKit

@main
struct STARGAZEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(APOD_DataFetcher())
                .environment(NEO_DataFetcher())
                .environment(SERP_DataFetcher())
                .implementPopupView()
        }
    }
    
    init() {
        try? Tips.configure()
//        try? Tips.resetDatastore()
    }
}
