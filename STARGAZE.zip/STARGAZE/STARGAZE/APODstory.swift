import SwiftUI

struct APODstory: View {
    let item: AstronomyPictureoftheDay
    
    var body: some View {
        VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/){
            AsyncImage(url: item.url) { image in
                image
                    .resizable()
                    .ignoresSafeArea()
            } placeholder: {
                ProgressView()
                    .frame(width: 300,height: 300)
            }
            
            Text(item.title)
                .font(.custom("Transcorner", size: 30))
                .rotation3DEffect(.degrees(15), axis: (x: 1, y: 0, z: 0))
                .shadow(color: .gray, radius: 2, x: 0, y: 10)
            HStack{
                Spacer()
                Group{
                    Text("Date:")
                        .bold()
                    Text(item.date)
                }
                
                Group{
                    Text("Copyright:")
                        .bold()
                    ScrollView(.horizontal){
                        Text(item.copyright.replacingOccurrences(of: "\n", with: ""))
                            .italic()
                    }
                }
                .font(.headline)
            }
            .frame(width: 390, height: 35)
            .border(Color.black,width:3)
            
            ScrollView{
                Text(item.explanation)
                    .padding(.horizontal)
                    .padding(.top,5)
                    .multilineTextAlignment(.center) //文字置中對齊
                    .lineSpacing(4)
                HStack{
                    ShareLink("TITLE", item: item.title)
                    ShareLink("COPYRIGHT", item: item.copyright)
//                    ShareLink("TITLE", item: item.title)
                }
                HStack{
//                    ShareLink("COPYRIGHT", item: item.copyright)
                    ShareLink("PICTURE", item: item.url)
                    ShareLink("DESCRIPTION", item: item.explanation)
                }
            }
        }
    }
}

#Preview {
    APODstory(item: AstronomyPictureoftheDay(copyright: "\nSteven Powell", date: "2023-12-19", explanation: "Could Queen Calafia's mythical island exist in space? Perhaps not, but by chance the outline of this molecular space cloud echoes the outline of the state of California, USA. Our Sun has its home within the Milky Way's Orion Arm, only about 1,000 light-years from the California Nebula. Also known as NGC 1499, the classic emission nebula is around 100 light-years long. On the featured image, the most prominent glow of the California Nebula is the red light characteristic of hydrogen atoms recombining with long lost electrons, stripped away (ionized) by energetic starlight. The star most likely providing the energetic starlight that ionizes much of the nebular gas is the bright, hot, bluish Xi Persei just to the right of the nebula.  A regular target for astrophotographers, the California Nebula can be spotted with a wide-field telescope under a dark sky toward the constellation of Perseus, not far from the Pleiades.   Explore Your Universe: Random APOD Generator", url: URL(string: "https://apod.nasa.gov/apod/image/2312/CalNeb_Powell_960.jpg")!, title: "NGC 1499: The California Nebula"))
}
