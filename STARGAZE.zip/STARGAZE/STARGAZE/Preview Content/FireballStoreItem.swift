import Foundation

struct SearchResponse: Codable {
    let data: [FireballStoreItem]
}

struct FireballStoreItem: Codable{
    let test:[trie]
//    var id = UUID()
//    let date: String
//    let energy:Double
//    let impactE: Double
//    let lat: Double
//    let latDir: String
//    let lon: Double
//    let lonDir: String
//    let alt: Double
//    let vel: Double
    
    enum CodingKeys: String,CodingKey {
        case test = "3"
    }
    
}

struct trie: Codable,Identifiable{
    
    var id = UUID()
    let date: String
    let energy:Double
    let impactE: Double
    
    enum CodingKeys: String,CodingKey {
        case date = "0"
        case energy = "1"
        case impactE = "2"
    }
}
