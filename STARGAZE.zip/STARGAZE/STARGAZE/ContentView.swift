import SwiftUI
import MijickPopupView
import TipKit

struct ContentView: View {
    
    var body: some View {
        TabView {
            homepage()
                .toolbarBackground(.visible, for: .tabBar)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("HOME")
                }
            APOD()
                .toolbarBackground(.visible, for: .tabBar)
                .tabItem {
                    Image(systemName: "photo")
                    Text("APOD")
                }
            NEO()
                .toolbarBackground(.visible, for: .tabBar)
                .tabItem {
                    Image(systemName: "globe.asia.australia.fill")
                    Text("NEO")
                }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    ContentView()
        .environment(APOD_DataFetcher())
        .environment(NEO_DataFetcher())
        .environment(SERP_DataFetcher())
        .implementPopupView()
}
