import SwiftUI

struct GoogleResults: View {
    let item: organicResults
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                if item.favicon == nil {
                    Image(systemName: "globe.americas.fill")
                }
                else {
                    AsyncImage(url: item.favicon) { image in
                        image
                    } placeholder: {
                        ProgressView()
                    }
                }
                
                VStack(alignment: .leading){
                    Text(item.source)
                        .font(.callout)
                    Text(item.displayedLink)
                        .lineLimit(1)
                        .font(.caption2)
                }
            }
            
            Link(item.title, destination: URL(string: "https://www.spacereference.org/asteroid/433-eros-a898-pa")!)
                .font(.title2)
                .lineLimit(1)
            Text(item.snippet!)
//                .font()
        }
        .padding()
    }
}

#Preview {
    GoogleResults(item: organicResults(position: 1, title: "Asteroid Eros", link: URL(string: "https://www.spacereference.org/asteroid/433-eros-a898-pa")!, displayedLink: "https://www.spacereference.org › 433-eros-a898-pa", favicon: URL(string: ""/*"https://serpapi.com/searches/6589b76924e88eb51174f4b5/images/db2ed0d92cfbf042705de564da87c93a4e36c40aee270a537304555b15363b9c.png"*/), snippet: "There are 11,600 Armor asteroids. There are several brighter ones! 433 Eros (A898 PA) 10.41 1036 Ganymed (A924 UB) 9.26 1627 Ivar (1929 SH) ...", source: "Cloudy Nights"))
}
