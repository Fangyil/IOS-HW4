import SwiftUI

struct NEOGoogle: View {
    let item: NearEarthObjects
    @Environment(SERP_DataFetcher.self) var fetcher
    @State private var showError = false
    @State private var error: Error?
    @State private var showingPopover = false

    func loaddata() {
        Task{
            do {
                try await fetcher.SERP_fetchData(name: item.name)
            } catch {
                self.error = error
                print(error.localizedDescription)
                showError = true
            }
        }
    }
    
    var body: some View {
        ZStack{
            ScrollView {
                if fetcher.items.isEmpty {
                    ProgressView()
                        .frame(width: 500,height: 700)
                }
                else {
                    ForEach(fetcher.items) { items in
                        GoogleResults(item: items)
                    }
                }
            }
            .task {
                loaddata()
            }
            .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {
            })
        }
    }
}

#Preview {
    NEOGoogle(item: NearEarthObjects(id: "2000433", name: "433 Eros (A898 PA)", nameLimited: "Eros", designation: "433", nasaJplUrl: URL(string: "https://ssd.jpl.nasa.gov/tools/sbdb_lookup.html#/?sstr=2000433")!))
        .environment(SERP_DataFetcher())
}
