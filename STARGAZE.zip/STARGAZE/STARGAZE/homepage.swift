import SwiftUI
import Swift
import MijickPopupView
import TipKit

struct homepage: View {
    private var tip = PopoverTip()
    @State var ChangeLanguage = false
    func saveSettings() {
        TopCustomPopup()
            .showAndStack()
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .center){
                Image("MilkyWay")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                ScrollView{
                    Link(destination: URL(string: "https://youtube.com/@NASA?si=g3zf7IiqRpL8l0Vc")!, label: {
                            Image("Nasa")
                                .cornerRadius(15)
                        })
                    .padding(.top,70)
                    NavigationLink {
                        Group {
                            if ChangeLanguage {
                                PopularScience(ChangeLanguage: $ChangeLanguage)
                                    .environment(\.locale, .init(identifier: "ch"))
                            }
                            else {
                                PopularScience(ChangeLanguage: $ChangeLanguage)
                                    .environment(\.locale, .init(identifier: "en"))
                            }
                        }
                        .toolbar(content: {
                            Button(action: {
                                ChangeLanguage.toggle()
                            }, label: {
                                Image(systemName: "network")
                            })
                        })
                    } label: {
                        ZStack{
                            Image("PopularScience")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 305)
                                .cornerRadius(15)
                            Text("Popular science\n about astronomy")
                                .foregroundColor(.white)
                                .font(.title)
                                .bold()
                            
                        }
                    }
                    
                    TipView(tip,arrowEdge: .top)
                        .frame(width: 370)
                    
                    Link(destination: URL(string: "https://www.facebook.com/NASA")!, label: {
                        ZStack{
                            Image("Facebook")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 305)
                                .cornerRadius(15)
                            Text("Facebook")
                                .foregroundColor(.white)
                                .font(.title)
                                .bold()
                                
                        }
                    })
                    Link(destination: URL(string: "https://www.instagram.com/nasa/")!, label: {
                        ZStack{
                            Image("Instagram")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300)
                                .cornerRadius(15)
                            Text("instagram")
                                .foregroundColor(.white)
                                .font(.title)
                                .bold()
                        }
                    })
                    Link(destination: URL(string: "https://twitter.com/NASA")!, label: {
                        ZStack{
                            Image("Twitter")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300)
                                .cornerRadius(15)
                            Text("twitter")
                                .foregroundColor(.white)
                                .font(.title)
                                .bold()
                        }
                    })
                    .padding(.bottom,90)
                }
            }
            .task {
                saveSettings()
            }
        }
    }
}

#Preview {
    homepage()
        .implementPopupView()
        .environment(SERP_DataFetcher())
}
