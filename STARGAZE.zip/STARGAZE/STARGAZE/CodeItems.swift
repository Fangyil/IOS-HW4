import Foundation

struct  AstronomyPictureoftheDay: Codable,Identifiable {
    var id: String{ date }
    let copyright: String
    let date: String
    let explanation: String
    let url: URL
    let title: String
    
}

struct neos: Codable {
    let NearEarthObject: [NearEarthObjects]
    
    enum CodingKeys: String,CodingKey  {
        case NearEarthObject = "near_earth_objects"
    }
}

struct NearEarthObjects: Codable,Identifiable {
    let id: String
    let name: String
    let nameLimited: String
    let designation: String
    let nasaJplUrl: URL
    
    enum CodingKeys: String, CodingKey  {
        case id
        case name
        case nameLimited = "name_limited"
        case designation
        case nasaJplUrl = "nasa_jpl_url"
    }
    
}

struct SerpItem: Codable {
    let organicResult: [organicResults]
    enum CodingKeys: String, CodingKey  {
        case organicResult = "organic_results"
    }
}

struct organicResults: Codable,Identifiable {
    var id: Int{ position }
    let position: Int
    let title: String
    let link: URL
    let displayedLink: String
    let favicon: URL?
    let snippet: String?
    let source: String
    
    enum CodingKeys: String, CodingKey  {
        case position
        case title
        case link
        case displayedLink = "displayed_link"
        case favicon
        case snippet
        case source
    }
}

//struct FireballItem: Codable,Identifiable {
//    let id: String
//    let neo: String
//    let absolute: Double
//    enum CodingKeys: String, CodingKey  {
//        case id
//        case neo = "neo_reference_id"
//        case absolute = "absolute_magnitude_h"
//    }
//}
