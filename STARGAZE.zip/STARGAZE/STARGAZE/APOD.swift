import SwiftUI

struct APOD: View {
    @Environment(\.refresh) private var refresh
    @Environment(APOD_DataFetcher.self) var fetcher
    @State private var showError = false
    @State private var error: Error?
    @GestureState private var dragOffset = CGSize.zero
    @State private var position: CGSize = .init(width: 150, height: -350)
    @State var showDatePicker: Bool = false
    @State var savedDate = Date()
    let formatter = DateFormatter()
    @State var progressValue = 0.0
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    var tip = DragTip()
    @State private var randomDate: Date?
    
    var body: some View {
        ZStack{
            VStack{
                if showError {
                    if error?.localizedDescription == "The data couldn’t be read because it is missing." {
                        ContentUnavailableView(
                            "No matchable APOD data😭",
                            image: "",
                            description: Text("Please choose another day.")
                        ) //找不到資料時的畫面
                    } else if error?.localizedDescription == "The Internet connection appears to be offline." {
                        ContentUnavailableView(
                            "Internet may be offline☹️",
                            systemImage: "exclamationmark.triangle.fill",
                            description: Text("Please check your Internet connection.")
                        ) //沒有網路時顯示的畫面
                    } else/* if error?.localizedDescription == "The operation couldn’t be completed. (STARGAZE.APOD_DataFetcher.FetchError error 1.)" */{
                        ZStack{
                            Button(action: {
                                generateRandomDate()
                                loaddata()
                            }, label: {
                                Image(systemName: "arrow.clockwise.circle")
                                    .font(.title)
                            }) //生成隨機日期
                            .offset(y: 70)
                            
                            ContentUnavailableView(
                                "Something went wrong😫",
                                image: "",
                                description: Text("NASA has not uploaded data for today."+"\n"+"Press the button to randomly advance one day.")
                            ) //找不到資料時的畫面
                        }
                    }
                }
                if !showError {
                    if fetcher.items.isEmpty {
                        ContentUnavailableView(label: {
                            ProgressView(value: progressValue)
                                .progressViewStyle(.circular)
                        }, description: {
                            Text("Loading...")
                            Text("\(progressValue*100, specifier: "%.2f")%")
                        }) //資料加載時顯示Loading畫面
                    }
                    ForEach(fetcher.items) { item in
                        APODstory(item: item)
                    }
                }
            }
            .onChange(of: savedDate, { oldValue, newValue in
                loaddata()
            })
            .task {
                if fetcher.items.isEmpty {
                    Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
                        withAnimation {
                            if progressValue >= 1.0 {
                                timer.invalidate()
                            } else {
                                progressValue += 0.1
                                if progressValue >= 1.0 {
                                    progressValue = 1.0
                                }
                            }
                        }
                    } //loading時進度條的動畫
                    loaddata()
                }
            }
//            .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {
//            })

            Button {
                showDatePicker.toggle()
            } label: {
                Image(systemName: "calendar.badge.clock")
                    .popoverTip(tip)
                    .font(.title.weight(.semibold))
                    .padding()
                    .background(Color.pink)
                    .foregroundColor(.white)
                    .clipShape(Circle())
                    .shadow(radius: 4, x: 4, y: 4)
                    .gesture(
                        DragGesture( coordinateSpace: .global)
                            .updating($dragOffset, body: { (value, state, transaction) in
                                state = value.translation //可以肆意移動Button位置
                            })
                            .onEnded({ (value) in
                                self.position.height += value.translation.height
                                self.position.width += value.translation.width
                            }) // 手勢變化時更新按鈕位置
                    )
            }
            .offset(x: position.width + dragOffset.width, y: position.height + dragOffset.height)
            
            if showDatePicker {
                DatePickerWithButtons(showDatePicker: $showDatePicker, savedDate: $savedDate, selectedDate: $savedDate)
                    .animation(.bouncy)
                    .transition(.opacity)
            }
        }
    }
    
    func loaddata(){
        Task{
            do {
                formatter.dateFormat = "yyyy-MM-dd"
                print(formatter.string(from: savedDate))
//                print(showError)
                try await fetcher.APOD_fetchData(date: formatter.string(from: savedDate))
                showError = false
            } catch {
                self.error = error
                print(error.localizedDescription)
                showError = true
            }
        }
    }
// 以下產生亂數日期
    private func generateRandomDate() {
        let startDate = Date(timeIntervalSinceNow: -31536000) // 一年前的日期

        if let randomDate = randomDateBetweenDates(start: startDate, end: Date()) {
            self.savedDate = randomDate
        }
    }
    private func randomDateBetweenDates(start: Date, end: Date) -> Date? {
        guard start < end else { return nil }

        _ = Calendar.current
        let randomTime = TimeInterval(arc4random_uniform(UInt32(end.timeIntervalSince(start))))
        let randomDate = start.addingTimeInterval(randomTime)

        return randomDate
    }
    private func formattedRandomDate() -> String {
        guard let randomDate = randomDate else {
            return "No date generated"
        }

        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: randomDate)
    }
}

struct DatePickerWithButtons: View {
    
    @Binding var showDatePicker: Bool
    @Binding var savedDate: Date
    @Binding var selectedDate: Date
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.3)
                .edgesIgnoringSafeArea(.all)
            VStack {
                DatePicker("Test", selection: $selectedDate, in: ...Date(), displayedComponents: .date)
                    .datePickerStyle(GraphicalDatePickerStyle())
                Divider()
                HStack {
                    Button(action: {
                        showDatePicker = false
                    }, label: {
                        Text("Cancel")
                    })
                    Spacer()
                    Button(action: {
                        showDatePicker = false
                        savedDate = selectedDate
                    }, label: {
                        Text("Save".uppercased())
                            .bold()
                    })
                }
                .padding(.horizontal)
            }
            .padding()
            .background(
                Color.white
                    .cornerRadius(30)
            )
        }

    }
}

#Preview {
    APOD()
        .environment(APOD_DataFetcher())
}
