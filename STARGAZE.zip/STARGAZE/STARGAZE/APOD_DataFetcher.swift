import Foundation
import SwiftUI

@Observable class APOD_DataFetcher {
    var items = [AstronomyPictureoftheDay]()
    
    enum FetchError: Error {
        case invalidURL
        case badRequest
    }
    
    func APOD_fetchData(date: String) async throws {
        let urlString = "https://api.nasa.gov/planetary/apod?api_key=9H0Rf28zgkP84HGpxsBiVjM6ElroSutpcfuWpVLq&date=\(date)"
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
//        do {
//            let dog = try JSONDecoder().decode(AstronomyPictureoftheDay.self, from: data)
//            print(dog)
//        } catch DecodingError.keyNotFound(let key, let context) {
//            print("keyNotFound", key, context)
//        } catch DecodingError.typeMismatch(let type, let context) {
//            print("typeMismatch", type, context)
//        } catch DecodingError.valueNotFound(let value, let context) {
//            print("valueNotFound", value, context)
//        } catch DecodingError.dataCorrupted(let context) {
//            print("dataCorrupted", context)
//        } catch  {
//            print(error)
//        }
//        print("APOD")
        
        let astronomyPictureoftheDay = try JSONDecoder().decode(AstronomyPictureoftheDay.self, from: data)
        items = [astronomyPictureoftheDay]
    }
}
