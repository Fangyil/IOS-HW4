import Foundation

@Observable class SERP_DataFetcher {
    var items = [organicResults]()
    
    enum FetchError: Error {
        case invalidURL
        case badRequest
    }
    
    func SERP_fetchData(name: String) async throws {
        let urlString = "https://serpapi.com/search.json?engine=google&q=\(name)&api_key=07f8ffde7122cd2aa0d4badd5336eecf18c091767ac2015b0d860d4585ed0fa1"
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
//        do {
//            let dog = try JSONDecoder().decode(SerpItem.self, from: data)
//            print(dog)
//        } catch DecodingError.keyNotFound(let key, let context) {
//            print("keyNotFound", key, context)
//        } catch DecodingError.typeMismatch(let type, let context) {
//            print("typeMismatch", type, context)
//        } catch DecodingError.valueNotFound(let value, let context) {
//            print("valueNotFound", value, context)
//        } catch DecodingError.dataCorrupted(let context) {
//            print("dataCorrupted", context)
//        } catch  {
//            print(error)
//        }
//        print("Serp")
        
        let serp = try JSONDecoder().decode(SerpItem.self, from: data)
        
        Task { @MainActor in
            items = serp.organicResult
        }
    }
    
}
