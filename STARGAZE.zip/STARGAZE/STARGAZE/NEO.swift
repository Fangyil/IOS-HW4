import SwiftUI
import TipKit

struct NEO: View {
    @Environment(NEO_DataFetcher.self) var fetcher
    @State private var showError = false
    @State private var error: Error?
    @State private var searchText = ""
    @State var progressValue = 0.0
    @State private var showingPopover = false
    @State private var isLoading = false
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    var tip = PopoverTip()
    func loaddata() {
        Task{
            do {
//                print("Catch")
                try await fetcher.NEO_fetchData()
            } catch {
                self.error = error
                print(error.localizedDescription)
                showError = true
            }
        }
    }
    func TimeCount() {
        Timer.scheduledTimer(withTimeInterval: /*0.3*/0.005, repeats: true) { timer in
                withAnimation {
                    if progressValue >= 1.0 {
                        timer.invalidate()
                    } else {
                        progressValue += 0.01
                        if progressValue > 1.0 {
                            progressValue = 1.0
                        }
                    }
                }
            } //loading時進度條的動畫
    }
    var searchResults: [NearEarthObjects] {
        let searchid = searchText
        
        if searchText == "" {
            loaddata()
            return fetcher.items //searchText為空時顯示所有資料
        } else {
            return searchid == nil ? fetcher.items : fetcher.items.filter{$0.id.contains(searchid)} //顯示含searchText的資料
        }
    }
    
    var body: some View {
        NavigationStack{
            List {
                if showError {
                    if error?.localizedDescription == "The data couldn’t be read because it is missing." {
                        ContentUnavailableView(
                            "No matchable APOD data😭",
                            image: "",
                            description: Text("Please choose another day.")
                        ) //找不到資料時的畫面
                    } else if error?.localizedDescription == "The Internet connection appears to be offline." {
                        ContentUnavailableView(
                            "Internet may be offline☹️",
                            systemImage: "exclamationmark.triangle.fill",
                            description: Text("Please check your Internet connection.")
                        ) //沒有網路時顯示的畫面
                    } else if error?.localizedDescription == "The operation couldn’t be completed. (STARGAZE.APOD_DataFetcher.FetchError error 1.)" {
                        ContentUnavailableView(
                            "Something went wrong😫",
                            image: "",
                            description: Text("Please refresh.")
                        ) //找不到資料時的畫面
                    }
                } else if !showError{
                    if progressValue == 0 || fetcher.items.isEmpty {
                       ContentUnavailableView(label: {
                           ProgressView(value: progressValue)
                       }, description: {
                           Text("Loading...")
                           Text("\(progressValue*100, specifier: "%.2f")%")
                       }) //資料加載時顯示Loading畫面
                    }
                    if progressValue == 1 {
                        ForEach(searchResults) { item in
                            NavigationLink {
                                NEOGoogle(item: item) //跳到介紹星球的畫面
                                    .toolbar(content: {
                                        Button(action: {
                                            showingPopover = true
                                        }, label: {
                                            Image(systemName: "globe.desk.fill")
                                                .font(.system(size: 20))
                                        })
                                        .popover(isPresented: $showingPopover, arrowEdge:.bottom) {
                                            VStack(alignment:.leading){
                                                Text("Name:  "+item.name)
                                                Text("ID:  "+item.id)
                                                Text("Designation:  "+item.designation)
                                                HStack{
                                                    Text("Name_limit: ")
                                                        .padding(.trailing,35)
                                                    Link(destination: item.nasaJplUrl, label: {
                                                        Text(item.nameLimited)
                                                            .font(.title)
                                                    })
                                                }
                                            }
                                            .frame(width: 300, height: 130)
                                            .presentationCompactAdaptation(.none)
                                        }
                                        .popoverTip(tip)
                                    })
                            } label: {
                                HStack{
                                    Text(item.id)
                                    Text(item.name)
                                }
                            }
                        }
                    }
                }
            }
            .task {
                TimeCount()
            }
            .refreshable {
                progressValue = 0.0
                TimeCount()
                loaddata()
            }
            .overlay {
                if !searchText.isEmpty, searchResults.isEmpty {
                    ContentUnavailableView.search //查無資料時的畫面
                }
            }
//            .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {
//            })
        }
        .searchable(text: $searchText)
    }
}

#Preview {
    NEO()
        .environment(NEO_DataFetcher())
        .environment(SERP_DataFetcher())
}
