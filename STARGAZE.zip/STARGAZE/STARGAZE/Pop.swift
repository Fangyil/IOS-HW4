import SwiftUI
import MijickPopupView

struct TopCustomPopup: TopPopup {
    func createContent() -> some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading,spacing: 0){
                Text("WELCOME TO STARGAZE!")
                Text("Enjoy your trip with us.")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            Spacer()
            
            Button(action: dismiss) { Text("Dismiss") }
        }
        .padding(.vertical, 20)
        .padding(.leading, 24)
        .padding(.trailing, 16)
    }
    func configurePopup(popup: TopPopupConfig) -> TopPopupConfig {
        popup
            .horizontalPadding(20)
            .topPadding(55)
            .cornerRadius(16)
    }
    func createButton() -> some View {
        Button(action: dismiss) { Text("Tap to close") }
    }
}

#Preview {
    TopCustomPopup()
        .implementPopupView()
}
