import Foundation

@Observable class NEO_DataFetcher {
    var items = [NearEarthObjects]()
    var item = NearEarthObjects.self
    
    enum FetchError: Error {
        case invalidURL
        case badRequest
    }
    
    func NEO_fetchData() async throws {
        let urlString = "https://api.nasa.gov/neo/rest/v1/neo/browse?api_key=9H0Rf28zgkP84HGpxsBiVjM6ElroSutpcfuWpVLq"
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
//        do {
//            let dog = try JSONDecoder().decode(neos.self, from: data)
//            print(dog)
//        } catch DecodingError.keyNotFound(let key, let context) {
//            print("keyNotFound", key, context)
//        } catch DecodingError.typeMismatch(let type, let context) {
//            print("typeMismatch", type, context)
//        } catch DecodingError.valueNotFound(let value, let context) {
//            print("valueNotFound", value, context)
//        } catch DecodingError.dataCorrupted(let context) {
//            print("dataCorrupted", context)
//        } catch  {
//            print(error)
//        }
//        print("NEO")
        
        let neo = try JSONDecoder().decode(neos.self, from: data)
        items = neo.NearEarthObject
    }
    
    func NEO2_fetchData(asteroid_id: String) async throws {
        let urlString = "https://api.nasa.gov/neo/rest/v1/neo/\(asteroid_id)?api_key=9H0Rf28zgkP84HGpxsBiVjM6ElroSutpcfuWpVLq"
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
//        do {
//            let dog = try JSONDecoder().decode(NearEarthObjects.self, from: data)
//            print(dog)
//        } catch DecodingError.keyNotFound(let key, let context) {
//            print("keyNotFound", key, context)
//        } catch DecodingError.typeMismatch(let type, let context) {
//            print("typeMismatch", type, context)
//        } catch DecodingError.valueNotFound(let value, let context) {
//            print("valueNotFound", value, context)
//        } catch DecodingError.dataCorrupted(let context) {
//            print("dataCorrupted", context)
//        } catch  {
//            print(error)
//        }
//        print("NEO2")
        
        _ = try JSONDecoder().decode(NearEarthObjects.self, from: data)
    }
}
