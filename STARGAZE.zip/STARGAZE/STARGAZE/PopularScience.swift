import SwiftUI

struct PopularScience: View {
    @Binding var ChangeLanguage : Bool
    @State private var isExpanded = true
    @State var search = ""
    @State var CelestialBodies = ["Stars", "Planets", "Satellites",  "Galaxies", "Asteroids", "Comets", "Nebulae", "Black Holes", "Exoplanets", "Quasars"]
    @State var PlanetsandSolarSystems = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Solar System", "Planetary Motion", "Planetary Satellites", "Asteroid Belt and Comets"]
    @State var StructureofGalaxies = ["Spiral Arms", "Central Bulge", "Disk", "Halo", "Globular Clusters", "Supermassive Black Hole", "Galaxy Groups and Clusters", "Intergalactic Medium"]
    @State var CosmicExpansion = ["Redshift", "Hubble's Law", "Big Bang Theory", "Consequences of Cosmic Expansion", "Dark Energy", "Future of Cosmic Expansion"]
    @State var BlackHolesandNeutronStars = ["Black Holes' Formation", "Black Holes' Types", "Black Holes' Hawking Radiation", "Black Holes' Event Horizon", "Black Holes' Observation", "Neutron Stars' Formation", "Neutron Stars' Composition", "Neutron Stars' Properties", "Neutron Stars' Observation", "Neutron Stars' Pulsars"]
    @State var DarkMatterandDarkEnergy = ["Invisible Matter of Dark Matter", "Gravitational Effects of Dark Matter", "Abundance of Dark Matter", "Particle Nature of Dark Matter", "Distribution of Dark Matter", "Accelerated Expansion of Dark Energy", "Cosmological Constant of Dark Energy", "Unknown Origin of Dark Energy", "Major Component of Dark Energy", "Expansion Influence of Dark Energy"]
    @State var CosmologicalTheories = ["Steady State Theory", "Big Bang Theory", "Inflationary Universe Theory", "Multiverse Hypothesis", "Cyclic Universe Models", "Brane Cosmology", "Emergent Universe Hypothesis", "Quantum Cosmology"]
    
    var body: some View {
        List{
            DisclosureGroup("Classification of Celestial Bodies",isExpanded: $isExpanded){
                homepagedetail(object:$CelestialBodies)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Planets and Solar Systems") {
                homepagedetail(object:$PlanetsandSolarSystems)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Structure of Galaxies") {
                homepagedetail(object: $StructureofGalaxies)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Cosmic Expansion") {
                homepagedetail(object: $CosmicExpansion)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Black Holes and Neutron Stars") {
                homepagedetail(object: $BlackHolesandNeutronStars)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Dark Matter and Dark Energy") {
                homepagedetail(object: $DarkMatterandDarkEnergy)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
            
            DisclosureGroup("Cosmological Theories") {
                homepagedetail(object: $CosmologicalTheories)
            }
            .listRowBackground(Glassmorphism(GlassWidth: 370, Glassheight: 50))
        }
        .scrollContentBackground(.hidden)
        .background{
            Image("MilkyWay")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
        }
    }
}

#Preview {
    PopularScience(ChangeLanguage: .constant(true))
        .environment(SERP_DataFetcher())
}

struct homepagedetail: View {
    @Environment(SERP_DataFetcher.self) var fetcher
    @State private var showError = false
    @State private var error: Error?
    @State var showingAlert = false
    @State var search = ""
    @Binding var object : Array<String>
    func loaddata() {
        Task{
            do {
                try await fetcher.SERP_fetchData(name: search)
            } catch {
                self.error = error
                print(error.localizedDescription)
                showError = true
            }
        }
    }
    
    var body: some View {
        ForEach($object.indices , id:\.self) { item in
            HStack{
                Text(object[item])
            }
//            .swipeActions(edge: .leading) {
//                Button(action: {
//                    
//                }, label: {
//                    Label("Like", systemImage: "heart")
//                })
//                .tint(.red)
//            }
            .swipeActions(edge: .trailing) {
                Button("Unread", systemImage: "envelope.badge", action: {
                    showingAlert.toggle()
                    search = object[item]
                })
                .tint(.blue)
            }
            .sheet(isPresented: $showingAlert) {
                ZStack{
                    ScrollView {
                        if fetcher.items.isEmpty {
                            ProgressView()
                                .frame(width: 500,height: 700)
                        }
                        else {
                            ForEach(fetcher.items) { items in
                                GoogleResults(item: items)
                            }
                        }
                    }
                    .task {
                        loaddata()
                    }
                    .alert(error?.localizedDescription ?? "", isPresented: $showError, actions: {
                    })
                }
            }
        }
    }
}
